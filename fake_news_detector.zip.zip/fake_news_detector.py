import pandas as pd
import numpy as np
import re
import pickle
import os
import warnings
from flask import Flask, request, jsonify
from flask_cors import CORS
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
warnings.filterwarnings('ignore')

app = Flask(__name__)
CORS(app)

class ImprovedFakeNewsDetector:
    def __init__(self):
        self.vectorizer = None
        self.ensemble_model = None
        self.is_trained = False
        self.feature_names = None
        self.training_stats = {}
    
    def enhanced_text_preprocessing(self, text):
        """Enhanced text preprocessing that preserves important features"""
        if not isinstance(text, str):
            return ''
        
        
        text = text.lower()
        
       
        url_count = len(re.findall(r'https?://\S+|www\.\S+', text))
        text = re.sub(r'https?://\S+|www\.\S+', ' URL_TOKEN ', text)
        
        
        text = re.sub(r'<[^>]+>', '', text)
        
        
        exclamation_count = text.count('!')
        question_count = text.count('?')
        
        
        text = re.sub(r'[!]{2,}', ' EXCLAMATION_PATTERN ', text)
        text = re.sub(r'[?]{2,}', ' QUESTION_PATTERN ', text)
        
        
        text = re.sub(r'[^\w\s!?.,;:]', ' ', text)
        
        
        text = re.sub(r'\s+', ' ', text).strip()
        
       
        metadata = {
            'url_count': url_count,
            'exclamation_count': exclamation_count,
            'question_count': question_count,
            'length': len(text),
            'word_count': len(text.split())
        }
        
        return text
    
    def load_and_validate_data(self, true_csv_path='True.csv', fake_csv_path='Fake.csv'):
        """Load data with proper validation"""
        try:
            logger.info("Loading and validating datasets...")
            
            
            true_df = pd.read_csv(true_csv_path)
            fake_df = pd.read_csv(fake_csv_path)
            
            logger.info(f"Loaded {len(true_df)} true news articles")
            logger.info(f"Loaded {len(fake_df)} fake news articles")
            
            
            true_df['label'] = 1
            fake_df['label'] = 0
            
            
            combined_df = pd.concat([true_df, fake_df], ignore_index=True)
            
            
            logger.info("Validating data...")
            logger.info(f"Total samples: {len(combined_df)}")
            logger.info(f"True news samples: {len(combined_df[combined_df['label'] == 1])}")
            logger.info(f"Fake news samples: {len(combined_df[combined_df['label'] == 0])}")
            
            
            missing_text = combined_df['text'].isnull().sum()
            if missing_text > 0:
                logger.warning(f"Found {missing_text} missing text entries, removing them")
                combined_df = combined_df.dropna(subset=['text'])
            
            
            combined_df['text_length'] = combined_df['text'].astype(str).str.len()
            short_articles = len(combined_df[combined_df['text_length'] < 50])
            if short_articles > 0:
                logger.info(f"Removing {short_articles} articles with less than 50 characters")
                combined_df = combined_df[combined_df['text_length'] >= 50]
            
            
            combined_df = combined_df.sample(frac=1, random_state=42).reset_index(drop=True)
            
            
            logger.info("Preprocessing text...")
            combined_df['processed_text'] = combined_df['text'].apply(self.enhanced_text_preprocessing)
            
            
            empty_processed = combined_df['processed_text'].str.strip().eq('').sum()
            if empty_processed > 0:
                logger.warning(f"Removing {empty_processed} articles with empty processed text")
                combined_df = combined_df[combined_df['processed_text'].str.strip() != '']
            
            logger.info(f"Final dataset size: {len(combined_df)} articles")
            
            return combined_df[['processed_text', 'label']]
            
        except Exception as e:
            logger.error(f"Error in data loading/validation: {str(e)}")
            raise
    
    def create_advanced_features(self, texts):
        """Create advanced features beyond TF-IDF"""
        features = []
        
        for text in texts:
            text_features = {
                'char_count': len(text),
                'word_count': len(text.split()),
                'sentence_count': len(re.split(r'[.!?]+', text)),
                'avg_word_length': np.mean([len(word) for word in text.split()]) if text.split() else 0,
                'exclamation_ratio': text.count('!') / len(text) if len(text) > 0 else 0,
                'question_ratio': text.count('?') / len(text) if len(text) > 0 else 0,
                'uppercase_ratio': sum(1 for c in text if c.isupper()) / len(text) if len(text) > 0 else 0,
                'digit_ratio': sum(1 for c in text if c.isdigit()) / len(text) if len(text) > 0 else 0,
            }
            features.append(list(text_features.values()))
        
        return np.array(features)
    
    def train_models(self, true_csv_path='True.csv', fake_csv_path='Fake.csv'):
        """Train improved models with better validation"""
        try:
            logger.info("Starting improved model training...")
            
            # Load and validate data
            data = self.load_and_validate_data(true_csv_path, fake_csv_path)
            
            X = data['processed_text']
            y = data['label']
            
            # Split data with stratification
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=y
            )
            
            logger.info(f"Training set: {len(X_train)} samples")
            logger.info(f"Test set: {len(X_test)} samples")
            logger.info(f"Training set label distribution: {y_train.value_counts().to_dict()}")
            
            # Enhanced TF-IDF Vectorization
            logger.info("Creating enhanced TF-IDF features...")
            self.vectorizer = TfidfVectorizer(
                max_features=10000,
                stop_words='english',
                ngram_range=(1, 3),  
                min_df=2,
                max_df=0.95,
                sublinear_tf=True
            )
            
            X_train_tfidf = self.vectorizer.fit_transform(X_train)
            X_test_tfidf = self.vectorizer.transform(X_test)
            
        
            logger.info("Creating additional features...")
            X_train_additional = self.create_advanced_features(X_train)
            X_test_additional = self.create_advanced_features(X_test)
            
            
            from scipy.sparse import hstack, csr_matrix
            X_train_combined = hstack([X_train_tfidf, csr_matrix(X_train_additional)])
            X_test_combined = hstack([X_test_tfidf, csr_matrix(X_test_additional)])
            
            
            logger.info("Training individual models...")
            
            
            lr_model = LogisticRegression(
                random_state=42, 
                max_iter=2000,
                C=1.0,
                class_weight='balanced'  
            )
            
            
            rf_model = RandomForestClassifier(
                n_estimators=200,
                max_depth=20,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=42,
                class_weight='balanced'
            )
            
            
            gb_model = GradientBoostingClassifier(
                n_estimators=200,
                learning_rate=0.1,
                max_depth=6,
                min_samples_split=5,
                random_state=42
            )
            
            
            self.ensemble_model = VotingClassifier(
                estimators=[
                    ('lr', lr_model),
                    ('rf', rf_model),
                    ('gb', gb_model)
                ],
                voting='soft'  
            )
            
            
            logger.info("Training ensemble model...")
            self.ensemble_model.fit(X_train_combined, y_train)
            
            
            logger.info("Evaluating models...")
            
            
            train_predictions = self.ensemble_model.predict(X_train_combined)
            train_accuracy = accuracy_score(y_train, train_predictions)
            
            
            test_predictions = self.ensemble_model.predict(X_test_combined)
            test_accuracy = accuracy_score(y_test, test_predictions)
            
            
            cv_scores = cross_val_score(self.ensemble_model, X_train_combined, y_train, cv=5)
            
            
            self.training_stats = {
                'train_accuracy': train_accuracy,
                'test_accuracy': test_accuracy,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'confusion_matrix': confusion_matrix(y_test, test_predictions).tolist(),
                'classification_report': classification_report(y_test, test_predictions, output_dict=True)
            }
            
            logger.info(f"Training Accuracy: {train_accuracy:.4f}")
            logger.info(f"Test Accuracy: {test_accuracy:.4f}")
            logger.info(f"Cross-validation: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
            
            
            logger.info("\nClassification Report:")
            logger.info(classification_report(y_test, test_predictions))
            
            self.is_trained = True
            logger.info(" Model training completed successfully!")
            
            return self.training_stats
            
        except Exception as e:
            logger.error(f"Error during training: {str(e)}")
            raise
    
    def predict(self, text):
        """Make prediction with confidence scores"""
        if not self.is_trained:
            raise ValueError("Models must be trained before prediction")
        
        try:
            # Preprocess text
            processed_text = self.enhanced_text_preprocessing(text)
            
            if not processed_text.strip():
                return {"error": "Text is empty after preprocessing"}
            
            # Vectorize text
            text_tfidf = self.vectorizer.transform([processed_text])
            
            # Create additional features
            additional_features = self.create_advanced_features([processed_text])
            
            # Combine features
            from scipy.sparse import hstack, csr_matrix
            combined_features = hstack([text_tfidf, csr_matrix(additional_features)])
            
            # Make prediction
            prediction = self.ensemble_model.predict(combined_features)[0]
            probabilities = self.ensemble_model.predict_proba(combined_features)[0]
            
            # Get individual model predictions for transparency
            individual_predictions = {}
            for name, model in self.ensemble_model.named_estimators_.items():
                pred = model.predict(combined_features)[0]
                prob = model.predict_proba(combined_features)[0]
                individual_predictions[name] = {
                    'prediction': 'Real News' if pred == 1 else 'Fake News',
                    'confidence': float(max(prob))
                }
            
            result = {
                'input_text': text[:200] + '...' if len(text) > 200 else text,
                'processed_text_length': len(processed_text),
                'final_prediction': 'Real News' if prediction == 1 else 'Fake News',
                'confidence': float(max(probabilities)),
                'probability_fake': float(probabilities[0]),
                'probability_real': float(probabilities[1]),
                'individual_models': individual_predictions,
                'interpretation': self._interpret_prediction(probabilities)
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error during prediction: {str(e)}")
            return {"error": f"Prediction failed: {str(e)}"}
    
    def _interpret_prediction(self, probabilities):
        """Provide interpretation of the prediction"""
        confidence = max(probabilities)
        
        if confidence > 0.9:
            certainty = "Very High"
        elif confidence > 0.8:
            certainty = "High"
        elif confidence > 0.7:
            certainty = "Moderate"
        elif confidence > 0.6:
            certainty = "Low"
        else:
            certainty = "Very Low"
        
        return f"Prediction certainty: {certainty} ({confidence:.2%})"
    
    def save_models(self, model_dir='models'):
        """Save trained models and statistics"""
        if not self.is_trained:
            raise ValueError("Models must be trained before saving")
        
        os.makedirs(model_dir, exist_ok=True)
        
        # Save models
        with open(f'{model_dir}/vectorizer.pkl', 'wb') as f:
            pickle.dump(self.vectorizer, f)
        with open(f'{model_dir}/ensemble_model.pkl', 'wb') as f:
            pickle.dump(self.ensemble_model, f)
        with open(f'{model_dir}/training_stats.pkl', 'wb') as f:
            pickle.dump(self.training_stats, f)
        
        logger.info(f" Models and statistics saved to {model_dir}/")
    
    def load_models(self, model_dir='models'):
        """Load pre-trained models"""
        try:
            with open(f'{model_dir}/vectorizer.pkl', 'rb') as f:
                self.vectorizer = pickle.load(f)
            with open(f'{model_dir}/ensemble_model.pkl', 'rb') as f:
                self.ensemble_model = pickle.load(f)
            
            # Try to load training stats
            try:
                with open(f'{model_dir}/training_stats.pkl', 'rb') as f:
                    self.training_stats = pickle.load(f)
            except FileNotFoundError:
                self.training_stats = {}
            
            self.is_trained = True
            logger.info(" Models loaded successfully!")
            
        except Exception as e:
            logger.error(f"Error loading models: {str(e)}")
            raise

# Initialize improved detector
detector = ImprovedFakeNewsDetector()

@app.route('/', methods=['GET'])
def home():
    return jsonify({
        "message": "Improved Fake News Detector API",
        "version": "2.0",
        "features": [
            "Enhanced text preprocessing",
            "Advanced feature engineering",
            "Ensemble model with voting",
            "Detailed confidence scores",
            "Individual model predictions"
        ],
        "endpoints": {
            "/train": "POST - Train models with CSV files",
            "/predict": "POST - Predict if news is fake",
            "/health": "GET - Check API health",
            "/stats": "GET - Get training statistics"
        }
    })

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status": "healthy",
        "models_trained": detector.is_trained,
        "training_stats": detector.training_stats if detector.is_trained else None
    })

@app.route('/stats', methods=['GET'])
def get_stats():
    if not detector.is_trained:
        return jsonify({
            "status": "error",
            "message": "Models not trained yet"
        }), 400
    
    return jsonify({
        "status": "success",
        "training_statistics": detector.training_stats
    })

@app.route('/train', methods=['POST'])
def train():
    try:
        data = request.get_json() or {}
        true_path = data.get('true_csv_path', 'True.csv')
        fake_path = data.get('fake_csv_path', 'Fake.csv')
        
        stats = detector.train_models(true_path, fake_path)
        detector.save_models()
        
        return jsonify({
            "status": "success",
            "message": "Improved models trained and saved successfully",
            "training_stats": stats
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        if not data or 'text' not in data:
            return jsonify({
                "status": "error",
                "message": "Missing 'text' field in request body"
            }), 400
        
        text = data['text']
        if not text or not text.strip():
            return jsonify({
                "status": "error",
                "message": "Text cannot be empty"
            }), 400
        
        result = detector.predict(text)
        
        if "error" in result:
            return jsonify({
                "status": "error",
                "message": result["error"]
            }), 400
        
        return jsonify({
            "status": "success",
            "result": result
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

if __name__ == '__main__':
    print(" Starting Improved Fake News Detector API...")
    
    # Try to load existing models
    try:
        detector.load_models()
        print(" Pre-trained models loaded successfully!")
        if detector.training_stats:
            print(f" Model Accuracy: {detector.training_stats.get('test_accuracy', 'N/A'):.3f}")
    except:
        print(" No pre-trained models found.")
        print(" Send POST request to /train to train new models")
    
    # Setup ngrok for public URL
    try:
        from pyngrok import ngrok
        
        ngrok.kill()
        public_tunnel = ngrok.connect(5000)
        public_url = public_tunnel.public_url
        
        print("\n" + "="*60)
        print(" IMPROVED FAKE NEWS DETECTOR IS READY!")
        print(f" Public URL: {public_url}")
        print(f" Prediction Endpoint: {public_url}/predict")
        print(f" Statistics: {public_url}/stats")
        print("="*60)
        
    except Exception as e:
        print(f" Ngrok setup failed: {e}")
        print(" Running locally on http://localhost:5000")
    
    app.run(debug=False, host='0.0.0.0', port=5000, use_reloader=False)